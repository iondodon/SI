#include "Led.h"

Led::Led(int pinNumber) {
    this->pin = pinNumber;
    pinMode(this->pin, OUTPUT);
};

void Led::on() {
    digitalWrite(pin, HIGH);
};

void Led::off() {
    digitalWrite(pin, LOW);
};

void Led::set(int mode) {
    digitalWrite(pin, mode);
}
