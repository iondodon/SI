#include "Piezo.h"
#include "Arduino.h"


Piezo::Piezo(int pinNumber) {
    this->pin = pinNumber;
    pinMode(pinNumber, OUTPUT);
};
