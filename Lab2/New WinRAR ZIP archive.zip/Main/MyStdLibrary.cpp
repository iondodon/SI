#include "MyStdLibrary.h"
 

static int MyStdLibrary::LCDPutChar(char c, FILE *stream)
{   MyStdLibrary::lcd=lcd;
    lcd.print(c) ;
    return 0 ;
}


static int MyStdLibrary::LCDGetChar()
{
    return 0 ;
}

static int MyStdLibrary::KeypadPutChar(char ch, FILE *stream)
{
    return 0;
}

static char MyStdLibrary::KeypadGetChar()
{   char ch;
    do{ch = 0;
        ch = MyStdLibrary::keyPad.getKey();
      }
    while(ch==0);
    return ch ;
}
static int MyStdLibrary::SerialPutChar(char c, FILE *stream)
{
    Serial.write(c) ;
    return 0 ;
}

static char MyStdLibrary::SerialGetChar(FILE *stream)
{
    char c;
    while(Serial.available()) {  
       c = Serial.read();
       printf("%c", c);  
    }
    return c;
}

String MyStdLibrary::readStr() {
  char c;
  String str;
  do {
    scanf("%c", &c);
    if(c != 0 && c != '\r'){
      str.concat(c);
    }
  }while(c!= '\r');

  return str;
}

void MyStdLibrary::writeStr(String str) {
  for(int i = 0; i < str.length(); i++) {
    printf("%c", str[i]);
  }
}


void MyStdLibrary::open(LiquidCrystal lcd) { 
     MyStdLibrary::lcd=lcd; 
     f = fdevopen(MyStdLibrary::LCDPutChar, MyStdLibrary::LCDGetChar);
   
  stdout = f;
  stdin = f;}

void MyStdLibrary::open(String str) { 
  if(str=="Serial"){
  f = fdevopen(MyStdLibrary::SerialPutChar, MyStdLibrary::SerialGetChar);}
  
  stdout = f;
  stdin = f;}

void MyStdLibrary::open(Keypad keyPad) { 
      MyStdLibrary::keyPad=keyPad;
     f = fdevopen(MyStdLibrary::KeypadPutChar, MyStdLibrary::KeypadGetChar);
    
  stdout = f;
  stdin = f;}
  
MyStdLibrary::MyStdLibrary( ) {
  
}
