#include "Button.h"
#include "Arduino.h"

Button::Button(int pinNumber) {
    this->pin = pinNumber;
    pinMode(pinNumber, INPUT);
};

int Button::read() {
    return digitalRead(pin);
}
