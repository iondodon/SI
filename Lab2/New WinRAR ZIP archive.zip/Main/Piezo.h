#ifndef Piezo_h
#define Piezo_h
#include "Arduino.h"

class Piezo {
    private:
        int pin;
    public:
        Piezo(int pinNumber);
};

#endif
