#ifndef MUSTDIO_HEADER
#define MUSTDIO_HEADER

#include <stdio.h>
#include <Arduino.h>
#include <LiquidCrystal.h> 
#include <Password.h> 
#include <Keypad.h> 
static FILE *f;


class MyStdLibrary {  
  public:
    static Keypad keyPad;
    static LiquidCrystal lcd; 
    MyStdLibrary();
    String readStr();
    void writeStr(String str);
    static int SerialPutChar(char c, FILE *stream);
    static char SerialGetChar(FILE *stream);
    static int LCDPutChar(char c, FILE *stream);
    static int LCDGetChar();
    static int KeypadPutChar(char c, FILE *stream);
    static char KeypadGetChar();
    void open(LiquidCrystal lcd);
    void open(String str);
    void open(Keypad keyPad);


};

#endif
