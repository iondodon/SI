#include "Arduino.h"

class Button {
    private:
        int pin;
    public:
        Button(int pinNumber);
        int read();
};
