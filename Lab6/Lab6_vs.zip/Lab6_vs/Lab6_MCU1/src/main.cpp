#include "../include/Lab1/libs.h"
#include "../include/Lab1/conts.h"

Lcd *lcd;
MySerial *serial;
StaticJsonDocument<200> packet;
DynamicJsonDocument doc(1024);

int distance;
char receive[5];
int nr = 1;
int receiverId = 4;
char command[10];
String response = "";
int x = 0;
bool isValid = false;
const char* resp;

void receiveEvent(int);
void checkResponse();
void validatePacket();

void setup() {
  lcd = new Lcd(lcdPinOne, lcdPinTwo, lcdPinThree, lcdPinFour, lcdPinFive, lcdPinSix);
  serial = new MySerial();

  Wire.begin(address);
  Wire.onReceive(receiveEvent);
  lcd->openStream();
}

void loop() {
  delay(500);

  if(x % 3 == 0){
    strcpy(command, "blink_led");
  } else {
    strcpy(command, "get_data");
  }
  int size = sizeof(command);
  int checksum = size * 2;

  packet["start"] = "STX";
  packet["pkID"] = nr++;
  packet["data"] = command;
  packet["cksum"] = checksum;
  packet["type"] = "command";
  packet["recID"] = receiverId;
  packet["sendID"] = address;
  packet["end"] = "ETX";

  serializeJson(packet, Serial);

  memset(command, 0, sizeof(command));

  delay(500);
  if(serial->hasMessage()){
    delay(100);
    while(serial->hasMessage()){
      char c = Serial.read();
      response += c;
    }

    validatePacket();
    checkResponse();

  }

  delay(200);
  response = "";
  memset(receive, 0, sizeof(receive));
  x++;
  lcd->clearScreen();
}

void receiveEvent(int bytes){
  int i = 0;
  while(Wire.available()){
    receive[i] = Wire.read(); 
    i++;
  }
}

void checkResponse(){
  if(isValid){
    if(strncmp(resp, "dist", 4) == 0){
      lcd->setCursorLCD(0,0);
      printf("Distance:");
      lcd->setCursorLCD(0,1);
      printf("%s", resp);
    } else if (strcmp(resp, "blink") == 0){
      lcd->setCursorLCD(0,0);
      printf("%s", resp);
    }
  }
}

void validatePacket(){
  if(response.charAt(0) == '{' && response.charAt(response.length() - 1) == '}'){
      deserializeJson(doc, response);
      const char* startPacket = doc["start"];
      const char* endPacket = doc["end"];
      if(strcmp(startPacket, "STX") == 0 && strcmp(endPacket, "ETX") == 0 ){
        resp = doc["data"];
        int respChecksum = doc["cksum"];
        int sizeOfCommand = strlen(resp) + 2;
        if(respChecksum / 2 == sizeOfCommand){
          isValid = true;
        }
      }
    }
}