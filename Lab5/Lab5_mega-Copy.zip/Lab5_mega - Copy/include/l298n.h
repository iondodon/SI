#pragma once
#include <Arduino.h>

class L298n{
    private:
    uint8_t pin1;
    uint8_t pin2;
    uint8_t pwmPin;

    public:
    L298n(uint8_t, uint8_t, uint8_t);
    void forward();
    void backward();
    void stop();
    void setPwm(uint8_t);
};
