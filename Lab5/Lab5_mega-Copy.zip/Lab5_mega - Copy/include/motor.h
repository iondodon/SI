#pragma once
#include <Arduino.h>
#include <PID_v1.h>
#include "l298n.h"

class Motor{
    private:
    uint8_t pin1, pin2, speedPin;
    int speed;
    L298n *driver;
    double setPoint, input, output;
    double Kp = 0, Ki = 10, Kd = 0;
    int encoderSpeed, encoderLastSpeed;
    long endTime, startTime;
    int frequency = 24;
    int calculationStep;
    PID *pid;

    public:
    Motor(uint8_t, uint8_t, uint8_t);
    void moveForward();
    void moveBackward();
    void stop();
    void setSpeed(int);
    int getSpeed();
    void checkSpeed();
    double getRPM();
};
