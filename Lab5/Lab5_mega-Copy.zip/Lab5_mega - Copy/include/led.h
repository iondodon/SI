#pragma once
#include <Arduino.h>

class Led {
    private:
    uint8_t pin;
    uint8_t state;
    void setState(uint8_t);

    public:
    Led(uint8_t);
    void on();
    void off();
    void toggle();
    int ledIsOn();
    void blink(unsigned long);
};