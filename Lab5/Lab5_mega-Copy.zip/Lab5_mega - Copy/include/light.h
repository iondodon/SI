#pragma once
#include "..\include\relay.h"
#include <Arduino.h>

class Light{
    private:
    uint8_t pin;
    Relay *relay;

    public:
    Light(uint8_t);
    void turnLightON();
    void turnLightOFF();
    char* getStateLight();
};