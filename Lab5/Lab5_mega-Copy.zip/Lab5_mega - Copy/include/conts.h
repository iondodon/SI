#define buttonPin 2
#define yellowLedPin 13
#define redLedPin 6
#define greenLedPin 9
#define passLength 5
#define lcdPinOne A0
#define lcdPinTwo A1
#define lcdPinThree A2
#define lcdPinFour A3
#define lcdPinFive A4
#define lcdPinSix A5

#define tempSensorPin A8
#define dhtSensorPin 32

#define relayPin 37
#define speedPinMotor 7
#define carPinOne 39
#define carPinTwo 40

#define encoderPin 3
#define secMotorPinOne 43
#define secMotorPinTwo 44
#define secMotorSpeedPin 4

#define offset_press_button 0
#define offset_check_serial_input 500
#define offset_get_keypad_input 0
#define offset_check_keypad_input 500
#define offset_turn_off_leds 0 
#define offset_clear_screen 3000

#define offset_calculate_temp 0
#define offset_calculate_dht_temp 0
#define offset_calculate_dht_humidity 0

#define offset_direction 1200
#define offset_control_speed 1000
#define offset_control_climate 1000

#define rec_press_button 100
#define rec_check_serial_input 2000
#define rec_get_keypad_input 0
#define rec_check_keypad_input 1200
#define rec_turn_off_leds 3000 
#define rec_clear_screen 3000

#define rec_calculate_temp 1000
#define rec_calculate_dht_temp 1000
#define rec_calculate_dht_humidity 1000

#define rec_direction 1200
#define rec_control_speed 100
#define rec_control_climate 100
