bool inRange(int, int, int);
int isNumber(char*);
int convertToPwmValue(int);
