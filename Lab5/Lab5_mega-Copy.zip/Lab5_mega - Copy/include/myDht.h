#pragma once
#include <Arduino.h>
#include <DHT.h>
#include "sensor.h"

class MyDHT: public Sensor {
    private:
    int pin;
    DHT *dht;

    public:
    MyDHT(uint8_t pin);
    float getTemperature();
    float getHumidity();
};