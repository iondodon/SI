#pragma once
#include <Arduino.h>

class Relay{
    private:
    uint8_t pin;
    uint8_t state;
    void setState(uint8_t);
    int lampIsOn();

    public:
    Relay(uint8_t);
    void on();
    void off();
    void toggle();
    uint8_t getState();
};
