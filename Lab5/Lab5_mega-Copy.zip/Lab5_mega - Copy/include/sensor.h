#pragma once
#include <Arduino.h>

class Sensor {
    private:
    static const int saltPepperTotElem = 5;
    float saltPepperValues[saltPepperTotElem];
    int saltPepperIndex = 0;
    int saltPepperIsArrayFull = 0;
    static const int wAvgValuesTotElem = 4;
    float wAvgValues[wAvgValuesTotElem];
    float wAvgWeights[wAvgValuesTotElem] = {0.1, 0.15, 0.25, 0.5};
    int wAvgIsArrayFull = 0;

    float saltAndPepperFilter(float val);
    float weightedAvg(float val);
    float *copyArray(float *values, int n);
    void sort(float *values, int n);
    void shiftOneLeft(float *values, int n);
    float computeWeightedAvg(float *values, float *weights, int n);

    public:
    float filterValue(float value);
};