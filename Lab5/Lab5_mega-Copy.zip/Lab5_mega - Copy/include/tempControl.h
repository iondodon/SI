#pragma once
#include "relay.h"
#include "myDht.h"
#include <Arduino.h>

class TempControl{
    private:
    uint8_t heaterPin;
    uint8_t dhtPin;
    uint8_t hysteresis = 5;
    int tempSetPoint;
    Relay *heater;
    MyDHT *myDht;

    public:
    TempControl(uint8_t, uint8_t);
    float getTemperature();
    void checkHeater();
    void setTempSetPoint(int);
};
