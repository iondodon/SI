#pragma once
#include <Arduino.h>
#include "motor.h"
#include "tempControl.h"

class Car{
    private:
    uint8_t pin1;
    uint8_t pin2;
    uint8_t speedPin;
    Motor *motor;
    Motor *encMotor;
    TempControl *climate;

    public:
    Car(uint8_t, uint8_t, uint8_t);
    void moveCarForward(Motor*);
    void moveCarBackward(Motor*);
    void stopCar(Motor*);
    void setCarSpeed(Motor*, int);
    void setClimateTemp(int);
    int getCarSpeed(Motor*);
    float getClimateTemp();
    char* getCarDirection(Motor*);
    void controlClimate();
    void controlSpeed();
    double getMotorRPM();
    Motor* getMotor();
    Motor* getEncMotor();
};
