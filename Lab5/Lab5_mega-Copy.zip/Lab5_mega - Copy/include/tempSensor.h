#pragma once
#include <Arduino.h>
#include "sensor.h"

class TempSensor: public Sensor{
    private:
    const int minValue = 0;
    const int maxValue = 1024;
    const float maxValueVolts = 5.0;
    const int maxValueSensor = 150;
    const int minValueSensor = -50;
    const float maxVoltageValue = 9.0;
    const int pin;
    float adcToVoltage(int val);
    float voltageToPhi(float val);
    float saturateFilter(float val);

    public:
    TempSensor(uint8_t pin);
    float getValue();
};