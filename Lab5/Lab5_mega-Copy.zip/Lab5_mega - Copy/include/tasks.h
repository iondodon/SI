#pragma once

void Task_press_button();
void Task_get_serial_input();
void Task_check_serial_input();
void Task_get_keypad_input();
void Task_check_keypad_input();
void Task_turn_off_leds();
void Task_clear_screen();

void Task_calculate_temperature();
void Task_calculate_dhtTemp();
void Task_calculate_dhtHumidity();

void Task_direction();

void Task_show_motor_state();
void Task_show_climate_state();
void Task_control_speed();
void Task_control_climate();
