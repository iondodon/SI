#include "../include/motor.h"
#include "../include/l298n.h"
#include "../include/utils.h"
#include "../include/conts.h"

Motor::Motor(uint8_t pin1, uint8_t pin2, uint8_t sPin){
    this->driver = new L298n(pin1, pin2, sPin);
    pid = new PID(&input, &output, &setPoint, Kp, Ki, Kd, DIRECT);
    pid->SetMode(AUTOMATIC);
}
void Motor::moveForward(){
    this->driver->forward();
}

void Motor::moveBackward(){
    this->driver->backward();
}

void Motor::stop(){
    this->driver->stop();
}

void Motor::setSpeed(int speed){
    this->speed = speed;
    this->driver->setPwm(convertToPwmValue(speed));

    this->setPoint = speed;
    this->calculationStep = 10;
}
int Motor::getSpeed(){
    return this->speed;
}

void Motor::checkSpeed(){
    encoderSpeed = digitalRead(encoderPin);
    if(this->calculationStep || 
         (this->encoderSpeed != this->encoderLastSpeed &&
          this->encoderSpeed)){
            this->endTime = millis();
            this->input = (60000 * 1.0 / this->frequency / (this->endTime - this->startTime));
            this->startTime = this->endTime;
            this->pid->Compute();
            this->driver->setPwm(this->output);
            if(this->calculationStep > 0){
                this->calculationStep = this->calculationStep - 1;
            } else{
                this->calculationStep = 0;
            }
    }
    this->encoderLastSpeed = this->encoderSpeed;
}

double Motor::getRPM(){
    return this->input;
}
