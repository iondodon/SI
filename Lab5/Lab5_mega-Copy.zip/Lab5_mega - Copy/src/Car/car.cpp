#include "../include/car.h"
#include "../include/motor.h"
#include "../include/conts.h"
#include "../include/tempControl.h"

Car::Car(uint8_t pin1, uint8_t pin2, uint8_t sPin){
    this->motor = new Motor(pin1, pin2, sPin);
    this->climate = new TempControl(relayPin, dhtSensorPin);
    this->encMotor = new Motor(secMotorPinOne, secMotorPinTwo, secMotorSpeedPin);
}

void Car::moveCarForward(Motor* carMotor){
    carMotor->moveForward();
}

void Car::moveCarBackward(Motor* carMotor){
    carMotor->moveBackward();
}

void Car::stopCar(Motor* carMotor){
    carMotor->stop();
}

void Car::setCarSpeed(Motor* carMotor, int speed){
    carMotor->setSpeed(speed);
}

void Car::setClimateTemp(int temp){
    this->climate->setTempSetPoint(temp);
}

int Car::getCarSpeed(Motor* carMotor){
    return carMotor->getSpeed();
}

double Car::getMotorRPM(){
    return this->encMotor->getRPM();
}

float Car::getClimateTemp(){
    return this->climate->getTemperature();
}

void Car::controlClimate(){
    this->climate->checkHeater();
}

void Car::controlSpeed(){
    this->encMotor->checkSpeed();
}

char* Car::getCarDirection(Motor* carMotor){
    if(this->getCarSpeed(carMotor) < 0){
        this->moveCarBackward(carMotor);
        return "Backward";
    } else if (this ->getCarSpeed(carMotor) > 0){
        this->moveCarForward(carMotor);
        return "Forward";
    }else{
        this->stopCar(carMotor);
        return "Stopped";
    }   
}

Motor* Car::getMotor(){
    return this->motor;
}

Motor* Car::getEncMotor(){
    return this->encMotor;
}


