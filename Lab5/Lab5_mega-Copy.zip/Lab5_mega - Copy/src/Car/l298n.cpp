#include "../include/l298n.h"

   L298n::L298n(uint8_t pin1, uint8_t pin2, uint8_t pwmPin){
    this->pin1 = pin1;
    this->pin2 = pin2;
    this->pwmPin = pwmPin;
    pinMode(pin1, OUTPUT);
    pinMode(pin2, OUTPUT);
    pinMode(pwmPin, OUTPUT);
}

void L298n::forward(){
    digitalWrite(this->pin1, HIGH);
    digitalWrite(this->pin2, LOW);
}

void L298n::backward(){
    digitalWrite(this->pin1, LOW);
    digitalWrite(this->pin2, HIGH);
}

void L298n::stop(){
    digitalWrite(this->pin1, LOW);
    digitalWrite(this->pin2, LOW);
}

void L298n::setPwm(uint8_t speed){
    analogWrite(this->pwmPin, speed);
}
