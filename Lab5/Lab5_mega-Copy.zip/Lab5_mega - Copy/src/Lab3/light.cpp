#include "..\include\light.h"
#include "..\include\relay.h"

Light::Light(uint8_t pin){
    this->relay = new Relay(pin);
}

void Light::turnLightON(){
    this->relay->on();
}

void Light::turnLightOFF(){
    this->relay->off();
}

char* Light::getStateLight(){
    if(this->relay->getState()){
        return "ON";
    }else{
        return "OFF";
    }
}