#include "../include/relay.h"

Relay::Relay(uint8_t pin){
    this->pin = pin;
    pinMode(pin, OUTPUT);
    setState(LOW);
}

void Relay::setState(uint8_t state){
    this->state = state;
    digitalWrite(this->pin, state);
}

void Relay::on(){
    setState(HIGH);
}

void Relay::off(){
    setState(LOW);
}

int Relay::lampIsOn(){
    return this->state == HIGH;
}

void Relay::toggle(){
    if(lampIsOn()){
        off();
    }else{
        on();
    } 
}

uint8_t Relay::getState(){
    return this->state;
}
