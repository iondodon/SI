#include "../include/utils.h"
#include <Arduino.h>

bool inRange(int x, int low, int high){
  return ((x-high)*(x-low) <= 0);
}

int isNumber(char* input){
  for(int i = 0; i <= strlen(input); i++){
      if(isalpha(input[i])){
        return 0;
      }
  }
  return 1;
}

int convertToPwmValue(int speed){
  return map(abs(speed), 0, 100, 0, 255);
}

