#include "../include/tempControl.h"
#include "../include/relay.h"

TempControl::TempControl(uint8_t heaterPin, uint8_t dhtPin){
    this->heater = new Relay(heaterPin);
    this->myDht = new MyDHT(dhtPin);
}

float TempControl::getTemperature(){
    return this->myDht->getTemperature();
}

void TempControl::setTempSetPoint(int temp){
    this->tempSetPoint = temp;
}

void TempControl::checkHeater(){
    int temperature = getTemperature();
    if(temperature > this->tempSetPoint){
        heater->off();
    } else if (temperature <= this->tempSetPoint - this->hysteresis){
        heater->on();
    }
}
