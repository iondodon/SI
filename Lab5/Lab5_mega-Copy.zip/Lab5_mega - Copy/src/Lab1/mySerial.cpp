#include "../../include/mySerial.h"
#include "../../include/myStdio.h"
#include <Arduino.h>

MySerial::MySerial() {
    Serial1.begin(9600);
}

void MySerial::openStream() {
    FILE *fd = myStdioOpen(&Serial1);
    stdout = fd;
    stdin = fd;
}

int MySerial::isKeyPressed() {
    return Serial1.available();
}