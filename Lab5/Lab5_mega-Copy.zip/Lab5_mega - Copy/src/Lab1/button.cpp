#include <Arduino.h>
#include "../../include/button.h"

Button::Button(uint8_t pin) {
    this->pin = pin;
    pinMode(pin, INPUT);
}

int Button::buttonIsPressed(){
    int pressed = 0;
    int buttonState = digitalRead(this->pin);  
    if (buttonState == HIGH && previousState == LOW) {
        pressed = 1;
    }
    previousState = buttonState;
    return pressed;
}