#include "../../include/myKeypad.h"
#include <Keypad.h>
#include "../../include/myStdio.h"

const byte ROWS = 4;
const byte COLS = 4;

char keys[4][4] =
{
  {'7', '8', '9', '/'},
  {'4', '5', '6', 'X'},
  {'1', '2', '3', '-'},
  {'C', '0', '=', '+'}
};

byte rowPins[4] =  {22, 23, 24, 25};
byte colPins[4] =  {26, 27, 28, 29};

MyKeypad::MyKeypad() {
  this->keypad = new Keypad(makeKeymap(keys), rowPins, colPins, ROWS, COLS);
}

char MyKeypad::getKey() {
  if (this->key) {
    char k = this->key;
    this->key = NO_KEY;
    return k;
  }
  return NO_KEY;
}

void MyKeypad::openInputStream() {
  FILE *fd = myStdioOpen(this);
  stdin = fd;
}

int MyKeypad::isKeyPressed() {
  this->key = this->keypad->getKey();
  return key;
}