#include "tasks.h"
#include "conts.h"
#include "libs.h"

//GLOBAL VARIABLES
char input[20];
char keyInput[passLength];
int temperature;
extern int dhtTemp = 0; //de scos extern
extern int dhtHumidity = 0; //de scos extern
char dirM1[10];
char dirM2[10];
int speed, speedEncSetPoint;
int climateSetPoint;

//INITIALIZATION
Button *btn = new Button(buttonPin);
Led *yellowLed = new Led(yellowLedPin);
Led *greenLed = new Led(greenLedPin);
Led *redLed = new Led(redLedPin);
MySerial *serial = new MySerial();
MyKeypad *kpd = new MyKeypad();
Lcd *lcd = new Lcd(lcdPinOne, lcdPinTwo, lcdPinThree, lcdPinFour, lcdPinFive, lcdPinSix);

TempSensor *temp = new TempSensor(tempSensorPin);
// MyDHT *myDht = new MyDHT(dhtSensorPin);

Car *car = new Car(carPinOne, carPinTwo, speedPinMotor);
Light *light = new Light(relayPin);

// Car *carEnc = new Car(carPinOne, carPinTwo, encoderPin);

char ledON[] = "led_on";
char ledOFF[] = "led_off";
char key;
int keyInputCount = 0;
char password[passLength] = {'2', '0', '5', '5', '1'};

char tempCommand[] = "get_temp";
char dhtTempCommand[] = "dht_temp";
char dhtHumCommand[] = "dht_humidity";

char lampON[] = "lamp_on";
char lampOFF[] = "lamp_off";
char dirCommand[] = "motor_dir";
char setSpeedCommand[] = "motor_set_speed";
char getSpeedCommand[] = "motor_get_speed";

char dirEncCommand[] = "enc_motor_dir";
char setEncSpeedCommand[] = "enc_motor_set_speed";
char setClimateCommand[] = "set_climate";

void Task_press_button(){
    if(btn->buttonIsPressed()){
        yellowLed->toggle();
    }
}

void Task_get_serial_input(){
    if(serial->isKeyPressed()){
        serial->openStream();
        scanf("%s", input);
    }
}

void Task_check_serial_input(){
    serial->openStream();
    if(strcmp(input, ledON) == 0){
        yellowLed->on();
        printf("The led is ON\r\n");
    } else if(strcmp(input, ledOFF) == 0){
        yellowLed->off();
        printf("The led is OFF\r\n");
    } else if(strcmp(input, tempCommand) == 0){
        printf("LM35 sensor temperature: %d\r\n", temperature);
    } else if(strcmp(input, dhtTempCommand) == 0){
        printf("The dht sensor temperature: %d\r\n", dhtTemp);
    } else if(strcmp(input, dhtHumCommand) == 0){
        printf("The dht sensor humidity: %d\r\n", dhtHumidity);
    } else if(strcmp(input, lampON) == 0){
        light->turnLightON();
        lcd->openStream();
        printf("The lamp is ON");
         delay(1000); //de scos
        lcd->clearScreen(); //de scos
    } else if(strcmp(input, lampOFF) == 0){
        light->turnLightOFF();
        lcd->openStream();
        printf("The lamp is OFF");
         delay(1000); //de scos
        lcd->clearScreen(); //de scos
    } else if(strcmp(input, dirCommand) == 0){
        lcd->openStream();
        printf("Dir M: %s", dirM1);
                delay(1000); //de scos
        lcd->clearScreen(); //de scos
    } else if(strcmp(input, setSpeedCommand) == 0){
        printf("New motor speed: ");
        scanf("%d", &speed);
        if(inRange(speed, -100, 100)){
            car->setCarSpeed(car->getMotor(), speed);
            lcd->openStream();
            printf("New speed: %d", speed);
        } else {
            printf("Speed is not in range\r\n");
        }
        delay(1000); //de scos
        lcd->clearScreen(); //de scos
    } else if(strcmp(input, getSpeedCommand) == 0){
        lcd->openStream();
        printf("Current speed:%d", car->getCarSpeed(car->getMotor()));
    } else if(strcmp(input, dirEncCommand) == 0){
        lcd->openStream();
        printf("Dir encM: %s", dirM2);
    } else if(strcmp(input, setEncSpeedCommand) == 0){
        printf("Enter encoder motor speed set point: ");
        scanf("%d", &speedEncSetPoint);
        if(inRange(speedEncSetPoint, -100, 100)){
            car->setCarSpeed(car->getEncMotor(), speedEncSetPoint);
            lcd->openStream();
            while(!serial->isKeyPressed()){
                car->controlSpeed();//
                Task_show_motor_state();
                lcd->setCursorLCD(0,0);
            }
        } else {
            printf("Speed is not in range");
        }
        delay(1000); //de scos
        lcd->clearScreen(); // de  scos
    } else if(strcmp(input, setClimateCommand) == 0){
        printf("Enter climate set point: ");
        scanf("%d", &climateSetPoint);
        car->setClimateTemp(climateSetPoint);
        while(!serial->isKeyPressed()){
            car->controlClimate();//
            lcd->openStream();
            Task_show_climate_state();
            lcd->setCursorLCD(0,0);
            delay(1000);
        }
         delay(1000); //de scos
        lcd->clearScreen(); //de scos
    }
    memset(input, 0, sizeof(input));
}

void Task_get_keypad_input(){
    if(kpd->isKeyPressed()){
        kpd->openInputStream();
        scanf("%c", &key);
        keyInput[keyInputCount++] = key;
        lcd->openStream();
        printf("%c", key);
    }
}

void Task_check_keypad_input(){
    if(keyInputCount == passLength){
        lcd->openStream();
        lcd->setCursorLCD(0,1);
        if(strncmp(keyInput, password, 5) == 0){
            printf("Right pass");
            greenLed->on();
        }else{
            printf("Wrong pass");
            redLed->on();
        }
        memset(keyInput, 0, sizeof(keyInput));
        keyInputCount = 0;
    }
}

void Task_turn_off_leds(){
    if(redLed->ledIsOn() || greenLed->ledIsOn()){
        redLed->off();
        greenLed->off();
        lcd->clearScreen(); //de scos
    }
}

void Task_clear_screen(){
    lcd->clearScreen();
}

void Task_calculate_temperature(){
    temperature = (int)temp->getValue();
}

// void Task_calculate_dhtTemp(){
//     dhtTemp = (int)myDht->getTemperature();
// }

// void Task_calculate_dhtHumidity(){
//     dhtHumidity = (int)myDht->getHumidity();
// }

void Task_direction(){
    strcpy(dirM1,car->getCarDirection(car->getMotor()));
    strcpy(dirM2,car->getCarDirection(car->getEncMotor()));
}

int i = 0;
void Task_show_motor_state(){
    i++;
    if(i % 500 == 0){
        printf("Motor: Set:%d/%d", speedEncSetPoint, (int)car->getMotorRPM());
        i = 1;
    }
}

void Task_show_climate_state(){
     printf("Temp:  Set:%d/%d", climateSetPoint, (int)car->getClimateTemp());
}

void Task_control_speed(){
    car->controlSpeed();
}

void Task_control_climate(){
    car->controlClimate();
}
