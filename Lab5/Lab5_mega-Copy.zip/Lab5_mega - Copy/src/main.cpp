#include "libs.h"
#include "conts.h"

int rec_task_press_button = offset_press_button;
int rec_task_get_keypad_input = offset_get_keypad_input;
int rec_task_check_keypad_input = offset_check_keypad_input;
int rec_task_turn_off_leds = offset_turn_off_leds;
int rec_task_clear_screen = offset_clear_screen;

int rec_task_calculate_temp = offset_calculate_temp;
int rec_task_calculate_dht_temp = offset_calculate_dht_temp;
int rec_task_calculate_dht_humidity = offset_calculate_dht_humidity;

int rec_task_direction = offset_direction;
int rec_task_control_speed = offset_control_speed;
int rec_task_control_climate = offset_control_climate;

MyDHT* myDht; 
extern int dhtTemp; 
extern int dhtHumidity; 

void setup() {
  timer_init_ISR_1KHz(TIMER_DEFAULT);
  myDht = new MyDHT(dhtSensorPin);
}

void loop() {
  Task_get_serial_input();
  dhtTemp = (int)myDht->getTemperature(); //de scos
  dhtHumidity = (int)myDht->getHumidity(); //de scos
  delay(1000); //de scos
  Task_check_serial_input(); 
}

void timer_handle_interrupts(int timer){
  if(--rec_task_press_button <= 0){
    Task_press_button();
    rec_task_press_button = rec_press_button;
  }
  if(--rec_task_get_keypad_input <= 0){
    Task_get_keypad_input();
    rec_task_get_keypad_input = rec_get_keypad_input;
  }
  if(--rec_task_check_keypad_input <= 0){
    Task_check_keypad_input();
    rec_task_check_keypad_input = rec_check_keypad_input;
  }
  if(--rec_task_turn_off_leds <= 0){
    Task_turn_off_leds();
    rec_task_turn_off_leds = rec_turn_off_leds;
  }
  if(--rec_task_calculate_temp <= 0){
    Task_calculate_temperature();
    rec_task_calculate_temp = rec_calculate_temp;
  }
  // if(--rec_task_calculate_dht_temp <= 0){
  //   Task_calculate_dhtTemp();
  //   rec_task_calculate_dht_temp = rec_calculate_dht_temp;
  // }
  // if(--rec_task_calculate_dht_humidity <= 0){
  //   Task_calculate_dhtHumidity();
  //   rec_task_calculate_dht_humidity = rec_calculate_dht_humidity;
  // }
  // if(--rec_task_clear_screen <= 0){
  //   Task_clear_screen();
  //   rec_task_clear_screen = rec_clear_screen;
  // }
  if(--rec_task_direction <= 0){
    Task_direction();
    rec_task_direction = rec_direction;
  }
  // if(--rec_task_control_speed <= 0){
  //   Task_control_speed();
  //   rec_task_control_speed = rec_control_speed;
  // }
  // if(--rec_task_control_climate <= 0){
  //   Task_control_climate();
  //   rec_task_control_climate = rec_control_climate;
  // }
}