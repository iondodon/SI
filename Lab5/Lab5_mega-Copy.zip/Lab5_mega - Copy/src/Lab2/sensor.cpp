#include "../include/sensor.h"

float Sensor::filterValue(float value) {
    value = saltAndPepperFilter(value);
    value = weightedAvg(value);
    return value;
}

float *Sensor::copyArray(float *values, int n) {
    float *copy = new float[n];
    for (int i = 0; i < n; i++) {
        copy[i] = values[i];
    }
    return copy;
}

void Sensor::sort(float *values, int n) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n - 1; j++) {
            if (values[j] > values[j + 1]) {
                const float tmp = values[j];
                values[j] = values[j + 1];
                values[j + 1] = tmp;
            }
        }
    }
}

float Sensor::saltAndPepperFilter(float val) {
    saltPepperValues[saltPepperIndex++] = val;
    if (saltPepperIndex == saltPepperTotElem) {
        saltPepperIndex = 0;
        saltPepperIsArrayFull = 1;
    }
    if (saltPepperIsArrayFull) {
        float *copyOfValues = copyArray(saltPepperValues, saltPepperTotElem);
        sort(copyOfValues, saltPepperTotElem);
        const float data = copyOfValues[2];
        delete copyOfValues;
        return data;
    }
    float *copyOfValues = copyArray(saltPepperValues, saltPepperIndex);
    sort(copyOfValues, saltPepperIndex);
    const float data = copyOfValues[saltPepperIndex / 2];
    delete copyOfValues;
    return data;
}

void Sensor::shiftOneLeft(float *values, int n) {
    for (int i = 0; i < n - 1; i++) {
        values[i] = values[i + 1];
    }
}

float Sensor::computeWeightedAvg(float *values, float *weights, int n) {
    float total = 0;
    for (int i = 0; i < n; i++) {
        total += values[i] * weights[i];
    }
    return total;
}

float Sensor::weightedAvg(float val) {
    if (!wAvgIsArrayFull) {
        for (int i = 0; i < wAvgValuesTotElem; i++) {
            wAvgValues[i] = val;
        }
        wAvgIsArrayFull = 1;
    }
    shiftOneLeft(wAvgValues, wAvgValuesTotElem);
    wAvgValues[wAvgValuesTotElem - 1] = val;
    return computeWeightedAvg(wAvgValues, wAvgWeights, wAvgValuesTotElem);
}