#include "../include/myDht.h"

MyDHT::MyDHT(uint8_t pin): pin(pin) {
    dht = new DHT(pin, DHT11);
    dht->begin();
}

float MyDHT::getTemperature() {
    float tempValue = dht->readTemperature();
    return tempValue; //de pus filter
}

float MyDHT::getHumidity() {
    float humValue = dht->readHumidity();
    return filterValue(humValue);
}