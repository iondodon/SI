#include "tempSensor.h"

TempSensor::TempSensor(uint8_t pin): pin(pin){
}

float TempSensor::getValue(){
    analogReference(INTERNAL1V1);
    int analogValue = analogRead(pin);
    float voltageValue = adcToVoltage(analogValue);
    voltageValue = saturateFilter(voltageValue);
    voltageValue = filterValue(voltageValue);
    return voltageToPhi(voltageValue);
}

float TempSensor::saturateFilter(float val){
    if(val < minValue){
        val = minValue;
    }
    if(val > maxValue){
        val = maxValue;
    }
    return val;
}

float TempSensor::voltageToPhi(float val){
    return val * (maxValueSensor - minValueSensor) / maxVoltageValue;
}

float TempSensor::adcToVoltage(int val){
    return val * (maxValueVolts / maxValue);
}