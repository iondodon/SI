#ifndef FILTERS_HEADER
#define FILTERS_HEADER

void pushTemp(int *arr, int newTemp);
void swap(int &a, int &b);
void sortArr(int *arr);

void calculateMedian(int *rawBuff, int *medianBuff);
int getWeighterAverage(int *medianBuff);

#endif
